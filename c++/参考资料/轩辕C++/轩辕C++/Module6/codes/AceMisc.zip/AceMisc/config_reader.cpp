/*
 * config_reader.cpp
 *
 *  Created on: 2010-5-2 下午02:13:52
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/Configuration_Import_Export.h>

int main() {
    ACE_Configuration_Heap config;
    int rc = config.open();
    if (rc != 0)
        ACE_ERROR_RETURN(
                (LM_ERROR, "(%p)ACE_Configuration_Heap::open()\n"), -1);

    ACE_Ini_ImpExp importExport(config);
    if (importExport.import_config("test.cfg") != 0)
        ACE_ERROR_RETURN(
                (LM_ERROR, "(%p)ACE_Ini_ImpExp::import_config()\n"), -1);

    ACE_Configuration_Section_Key root = config.root_section();

    ACE_Configuration_Section_Key dbSection;
    if (config.open_section(root, "Database", 1, dbSection) == 0) {
        ACE_TString stringValue;
        if (config.get_string_value(dbSection, "db_user", stringValue) == 0)
            ACE_DEBUG((LM_DEBUG, "%s\n", stringValue.c_str()));
        if (config.get_string_value(dbSection, "db_passwd", stringValue) == 0)
            ACE_DEBUG((LM_DEBUG, "%s\n", stringValue.c_str()));
        // other items ...
    } else
        ACE_ERROR_RETURN((LM_ERROR,"(%t)open Database section failed!\n"),-1);

    ACE_Configuration_Section_Key chatSection;
    if (config.open_section(root, "ChatServer", 1, chatSection) == 0) {
        ACE_TString stringValue;
        if (config.get_string_value(chatSection, "listen_port", stringValue)
                == 0)
            ACE_DEBUG((LM_DEBUG, "%s\n", stringValue.c_str()));
        // other items ...
    } else
        ACE_ERROR_RETURN((LM_ERROR,"(%t)open ChatServer section failed!\n"),-1);

}
