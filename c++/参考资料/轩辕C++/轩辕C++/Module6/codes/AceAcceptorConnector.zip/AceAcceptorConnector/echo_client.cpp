/*
 * echo_client.cpp
 *
 *  Created on: 2010-5-1 上午09:32:57
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>

#include <ace/Svc_Handler.h>
#include <ace/SOCK_Stream.h>
#include <ace/SOCK_Connector.h>

#include <ace/Connector.h>

class InputHandler: public ACE_Svc_Handler<ACE_SOCK_Stream, ACE_NULL_SYNCH> {
public:
    typedef ACE_Svc_Handler<ACE_SOCK_Stream, ACE_NULL_SYNCH> Parent;
    enum {
        BUF_SIME = 512
    };

    virtual int open(void* a) {
        if (Parent::open(a) == -1)
            return -1;
        return this->activate(THR_NEW_LWP | THR_DETACHED);
    }
    virtual int handle_input(ACE_HANDLE) {
        ssize_t n = peer().recv(buf, BUF_SIME);
        if (n <= 0)
            ACE_ERROR_RETURN((LM_ERROR, "%p\n","peer().recv()"), -1);
        buf[n] = 0;
        ACE_DEBUG((LM_DEBUG, "%s\n", buf));
        return 0;
    }
    virtual int svc() {
        char inBuf[BUF_SIME] = "";
        while (std::cin.getline(inBuf, BUF_SIME)) {
            if (peer().send(inBuf, strlen(inBuf)) == -1) {
                ACE_ERROR((LM_ERROR, "%p\n", "peer().send()"));
                break;
            }
        }
        return 0;
    }

private:
    char buf[BUF_SIME];
};

typedef ACE_Connector<InputHandler, ACE_SOCK_Connector> MyConnector;

int main() {
    ACE_INET_Addr addr(8868, "127.0.0.1");
    MyConnector connector;

    InputHandler* p = 0;//由connector 创建 InputHandler
    if (connector.connect(p, addr) == -1)
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "connect()"), -1);

    ACE_Reactor::instance()->run_reactor_event_loop();
}
