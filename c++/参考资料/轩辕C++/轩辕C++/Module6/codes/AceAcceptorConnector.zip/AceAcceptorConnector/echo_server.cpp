/*
 * echo_server.cpp
 *
 *  Created on: 2010-5-1 上午09:18:06
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/Svc_Handler.h>
#include <ace/SOCK_Stream.h>
#include <ace/SOCK_Acceptor.h>
#include <ace/Acceptor.h>

class AcceptorHandler: public ACE_Svc_Handler<ACE_SOCK_Stream, ACE_NULL_SYNCH> {
public:
    typedef ACE_Svc_Handler<ACE_SOCK_Stream, ACE_NULL_SYNCH> Parent;
    enum {
        BUF_SIME = 512
    };

    virtual int handle_input(ACE_HANDLE h) {
        ACE_OS::sleep(5);
        ssize_t n = peer().recv(buf, BUF_SIME);

        if (n <= 0)
            ACE_ERROR_RETURN((LM_ERROR, "%p\n", "peer().recv()"), -1);
        if (peer().send(buf, n) == -1)
            ACE_ERROR_RETURN((LM_ERROR, "%p\n", "peer().send()"), -1);
        return 0;
    }
private:
    char buf[BUF_SIME];
};

typedef ACE_Acceptor<AcceptorHandler, ACE_SOCK_Acceptor> MyAcceptor;

int main() {
    ACE_INET_Addr addr(8868);
    MyAcceptor acceptor(addr, ACE_Reactor::instance());

    ACE_Reactor::instance()->run_reactor_event_loop();
}
