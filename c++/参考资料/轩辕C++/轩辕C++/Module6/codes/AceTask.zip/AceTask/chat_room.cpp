/*
 * chat_room.cpp
 *
 *  Created on: 2010-4-27 下午10:15:57
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */
#include <iostream>

#include <ace/SOCK_Dgram_Mcast.h>
#include <ace/Log_Msg.h>
#include <ace/Task.h>

class ChatRoom: public ACE_Task_Base {
public:
    int join(const ACE_INET_Addr& group) {
        _group = group;
        if (sock.join(_group) == -1)
            ACE_ERROR_RETURN((LM_ERROR,"%p\n", "join"), -1);

        return 0;
    }

    virtual int svc() {
        ACE_INET_Addr remoteAddr;
        for (;;) {
            memset(buf, 0, sizeof(buf));
            if (sock.recv(buf, sizeof(buf), remoteAddr) != -1) {
                ACE_DEBUG((LM_DEBUG, "recv msg from %s:%d: %s\n",
                                remoteAddr.get_host_addr(),
                                remoteAddr.get_port_number(), buf));
            } else {
                sock.leave(_group);
                break;
            }
        }
        return 0;
    }

    void sendMsg() {
        char sendBuf[512];
        for (;;) {
            memset(sendBuf, 0, sizeof(sendBuf));
            std::cin.getline(sendBuf, sizeof(sendBuf));

            if (sock.send(sendBuf, strlen(sendBuf)) == -1) {
                ACE_ERROR((LM_ERROR,"%p\n", "send"));
                sock.leave(_group);
                break;
            }
        }
    }

private:
    char buf[512];
    ACE_INET_Addr _group;
    ACE_SOCK_Dgram_Mcast sock;
};

int main() {
    ChatRoom cm;
    ACE_INET_Addr group(8000, "224.0.0.12");
    if (cm.join(group) == -1)
        return 1;

    cm.activate();
    cm.sendMsg();
}
