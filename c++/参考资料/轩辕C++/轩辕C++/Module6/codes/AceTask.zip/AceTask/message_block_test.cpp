/*
 * message_block_test.cpp
 *
 *  Created on: 2010-4-27 下午09:24:51
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/ACE.h>
#include <ace/Message_Block.h>
#include <ace/Log_Msg.h>

int main() {
    ACE_Message_Block *head = new ACE_Message_Block(8);
    ACE_Message_Block *mblk = head;

    for (;;) {
        ssize_t nbytes = ACE::read_n(ACE_STDIN, mblk->wr_ptr(), mblk->size());
        if (nbytes <= 0)
            break; // Break out at EOF or error.

        // Advance the write pointer to the end of the buffer.
        mblk->wr_ptr(nbytes);
        // Allocate message block and chain it at the end of list.
        mblk->cont(new ACE_Message_Block(8));
        mblk = mblk->cont();
    }
    // Print the contents of the list to the standard output.
    int i = 1;
    for (mblk = head; mblk != 0; mblk = mblk->cont()) {
        ACE_DEBUG((LM_DEBUG, "\n%dth message: ", i++));
        ACE::write_n(ACE_STDOUT, mblk->rd_ptr(), mblk->length());
    }

    head->release(); // This releases all the memory in the chain.
    return 0;
}
