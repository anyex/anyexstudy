/*
 * echo_server_mt.cpp
 *
 *  Created on: 2010-4-27 下午10:00:22
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/INET_Addr.h>
#include <ace/SOCK_Acceptor.h>
#include <ace/SOCK_Stream.h>
#include <ace/Thread_Manager.h>
#include <ace/Log_Msg.h>

static ACE_THR_FUNC_RETURN func(void* arg) {
    ACE_SOCK_Stream* socket = static_cast<ACE_SOCK_Stream*> (arg);

    char buf[512];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        ssize_t n;
        if ((n = socket->recv(buf, sizeof(buf))) <= 0) {
            ACE_ERROR((LM_ERROR, "%p\n", "recv()"));
            break;
        } else {
            if (socket->send(buf, n) == -1) {
                ACE_ERROR((LM_ERROR, "%p\n", "send()"));
                break;
            }
        }
    }
    socket->close();
    delete socket;
    return 0;
}

int main() {
    ACE_INET_Addr server_addr;
    ACE_SOCK_Acceptor acceptor;

    if (server_addr.set(8868) == -1)
        ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "set()"), 1);

    if (acceptor.open(server_addr) == -1)
        ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "open()"), 1);

    for (;;) {
        ACE_SOCK_Stream* peer = new ACE_SOCK_Stream;

        if (acceptor.accept(*peer) == -1)
            ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "accept()"), 1);
        peer->disable(ACE_NONBLOCK); // Ensure blocking <recv>s.

        ACE_Thread_Manager::instance()->spawn(func, peer);
    }

    return acceptor.close() == -1 ? 1 : 0;
}
