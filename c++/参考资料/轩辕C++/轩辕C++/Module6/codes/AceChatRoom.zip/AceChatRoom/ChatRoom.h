/*
 * ChatRoom.h
 *
 *  Created on: 2010-4-24 下午10:17:40
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef CHATROOM_H_
#define CHATROOM_H_

#include <list>
#include <ace/Singleton.h>
#include <ace/Null_Mutex.h>

class Participant;

class ChatRoom {
public:
    void join(Participant* user);
    void leave(Participant* user);

    void forwardMsg(const char* msg);

private:
    std::list<Participant*> users;
};

// 不加锁的方式
typedef ACE_Singleton<ChatRoom, ACE_Null_Mutex> Room;

#endif /* CHATROOM_H_ */
