/*
 * SignalHandler.cpp
 *
 *  Created on: 2010-4-24 下午10:04:51
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */
#include <ace/Log_Msg.h>

#include "SignalHandler.h"
#include "ChatRoom.h"

SignalHandler::SignalHandler(ACE_Reactor* reactor) {
    this->reactor(reactor);

    ACE_Sig_Set signals;
    signals.fill_set();

    this->reactor()->register_handler(signals, this);
}

int SignalHandler::handle_signal(int signum, siginfo_t*, ucontext_t*) {
    switch (signum) {
    case SIGINT:
        ACE_DEBUG((LM_DEBUG, "signal SIGINT, but not be terminated!\n"));
        break;
    case SIGUSR1:
        ACE_DEBUG((LM_DEBUG, "signal SIGUSR1, broadcast greeting ...\n"));
        Room::instance()->forwardMsg("hello every one!\n");
        break;
    case SIGUSR2:
        ACE_DEBUG((LM_DEBUG, "signal SIGUSR2, shutdown chat room ...\n"));
        this->reactor()->end_reactor_event_loop();
        break;
    }
    return 0;
}
