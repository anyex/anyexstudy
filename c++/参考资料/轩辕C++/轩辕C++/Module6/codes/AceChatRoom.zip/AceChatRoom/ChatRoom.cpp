/*
 * ChatRoom.cpp
 *
 *  Created on: 2010-4-24 下午10:17:40
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "ChatRoom.h"
#include "Participant.h"

void ChatRoom::join(Participant* user) {
    users.push_back(user);
}

void ChatRoom::leave(Participant* user) {
    std::list<Participant*>::iterator it = users.begin();
    for (; it != users.end(); ++it) {
        if (*it == user) {
            users.erase(it);
            break;
        }
    }
}

void ChatRoom::forwardMsg(const char* msg) {
    std::list<Participant*>::const_iterator it = users.begin();
    for (; it != users.end(); ++it) {
        ACE_SOCK_Stream& sock = (*it)->socket();
        if (sock.send(msg, std::strlen(msg)) == -1)
            (*it)->handle_close(ACE_INVALID_HANDLE, 0);
    }
}
