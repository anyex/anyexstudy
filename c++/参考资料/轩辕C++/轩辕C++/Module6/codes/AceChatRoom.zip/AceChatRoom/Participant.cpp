/*
 * Participant.cpp
 *
 *  Created on: 2010-4-24 下午10:04:39
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/Log_Msg.h>
#include <ace/Timer_Queue.h>

#include "Participant.h"
#include "ChatRoom.h"

ACE_Time_Value Participant::maxMsgInterval = ACE_Time_Value(5);

Participant::Participant(ACE_Reactor* reactor) {
    this->reactor(reactor);
}

int Participant::open() {
    lastMsgTime = reactor()->timer_queue()->gettimeofday();

    int result =
            reactor()->register_handler(this, ACE_Event_Handler::READ_MASK);
    if (result != 0)
        return result;

    result = reactor()->schedule_timer(this, 0, ACE_Time_Value::zero,
            maxMsgInterval);
    return result;

}

ACE_HANDLE Participant::get_handle() const {
    return sock.get_handle();
}

int Participant::handle_input(ACE_HANDLE h) {
    char buf[512] = "";
    ssize_t recvBytes = sock.recv(buf, sizeof(buf));

    if (recvBytes <= 0)
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "sock.recv"), -1);

    lastMsgTime = reactor()->timer_queue()->gettimeofday();
    Room::instance()->forwardMsg(buf);

    return 0;
}

int Participant::handle_timeout(const ACE_Time_Value& t, const void*) {
    if (t - lastMsgTime > maxMsgInterval)
        reactor()->remove_handler(this, ACE_Event_Handler::READ_MASK);

    return 0;
}

int Participant::handle_close(ACE_HANDLE h, ACE_Reactor_Mask closeMask) {
    if (sock.get_handle() != ACE_INVALID_HANDLE) {
        ACE_Reactor_Mask m = ACE_Event_Handler::ALL_EVENTS_MASK
                | ACE_Event_Handler::DONT_CALL;

        reactor()->cancel_timer(this);
        reactor()->remove_handler(this, m);
        sock.close();
        Room::instance()->leave(this);
        delete this;
    }

    return 0;
}

ACE_SOCK_Stream& Participant::socket() {
    return sock;
}
