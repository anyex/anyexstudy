/*
 * ChatMain.cpp
 *
 *  Created on: 2010-4-24 下午10:53:33
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/Reactor.h>

#include "ParticipantAcceptor.h"
#include "SignalHandler.h"

int main() {
    SignalHandler sh;

    ParticipantAcceptor acceptor;
    ACE_INET_Addr addr(8868);
    if (acceptor.open(addr) == -1)
        return 1;

    return ACE_Reactor::instance()->run_reactor_event_loop();
}
