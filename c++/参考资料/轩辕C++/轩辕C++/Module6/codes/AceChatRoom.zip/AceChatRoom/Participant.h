/*
 * Participant.h
 *
 *  Created on: 2010-4-24 下午10:04:39
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef PARTICIPANT_H_
#define PARTICIPANT_H_

#include <ace/Reactor.h>
#include <ace/Event_Handler.h>
#include <ace/SOCK_Acceptor.h>

class Participant: ACE_Event_Handler {
public:
    static ACE_Time_Value maxMsgInterval;

    Participant(ACE_Reactor* reactor = ACE_Reactor::instance());

    int open();

    virtual ACE_HANDLE get_handle() const;
    virtual int handle_input(ACE_HANDLE h = ACE_INVALID_HANDLE);
    virtual int handle_timeout(const ACE_Time_Value& t, const void* = 0);
    virtual int handle_close(ACE_HANDLE h, ACE_Reactor_Mask closeMask);

    ACE_SOCK_Stream& socket();

private:

    ACE_Time_Value lastMsgTime;
    ACE_SOCK_Stream sock;
};

#endif /* PARTICIPANT_H_ */
