/*
 * ParticipantAcceptor.cpp
 *
 *  Created on: 2010-4-24 下午10:04:24
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */
#include <ace/Log_Msg.h>

#include "ParticipantAcceptor.h"
#include "ChatRoom.h"
#include "Participant.h"

ParticipantAcceptor::ParticipantAcceptor(ACE_Reactor* reactor) {
    this->reactor(reactor);
}

ParticipantAcceptor::~ParticipantAcceptor() {
    handle_close(ACE_INVALID_HANDLE, 0);
}

int ParticipantAcceptor::open(const ACE_INET_Addr& addr) {
    if (acceptor.open(addr, 0) == -1)
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "acceptor.open"), -1);

    return reactor()->register_handler(this, ACE_Event_Handler::ACCEPT_MASK);
}

ACE_HANDLE ParticipantAcceptor::get_handle() const {
    return acceptor.get_handle();
}

int ParticipantAcceptor::handle_input(ACE_HANDLE h) {
    Participant* user = new Participant(reactor());

    if (acceptor.accept(user->socket()) == -1)
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "acceptor.accept"), -1);

    if (user->open() == -1) {
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "acceptor.accept"), -1);
        user->handle_close(ACE_INVALID_HANDLE, 0);
    } else {
        Room::instance()->join(user);
    }

    return 0;
}

int ParticipantAcceptor::handle_close(ACE_HANDLE h, ACE_Reactor_Mask closeMask) {
    if (acceptor.get_handle() != ACE_INVALID_HANDLE) {
        ACE_Reactor_Mask m = ACE_Event_Handler::ACCEPT_MASK
                | ACE_Event_Handler::DONT_CALL;

        reactor()->remove_handler(this, m);
        acceptor.close();
    }

    return 0;
}
