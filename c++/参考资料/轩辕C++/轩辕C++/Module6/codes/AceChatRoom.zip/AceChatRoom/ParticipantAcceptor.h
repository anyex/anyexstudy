/*
 * ParticipantAcceptor.h
 *
 *  Created on: 2010-4-24 下午10:04:24
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef PARTICIPANTACCEPTOR_H_
#define PARTICIPANTACCEPTOR_H_

#include <ace/Reactor.h>
#include <ace/Event_Handler.h>
#include <ace/SOCK_Acceptor.h>

class ParticipantAcceptor: ACE_Event_Handler {
public:
    ParticipantAcceptor(ACE_Reactor* reactor = ACE_Reactor::instance());
    virtual ~ParticipantAcceptor();

    int open(const ACE_INET_Addr& addr);

    virtual ACE_HANDLE get_handle() const;
    virtual int handle_input(ACE_HANDLE h = ACE_INVALID_HANDLE);
    virtual int handle_close(ACE_HANDLE h, ACE_Reactor_Mask closeMask);

private:
    ACE_SOCK_Acceptor acceptor;
};

#endif /* PARTICIPANTACCEPTOR_H_ */
