/*
 * SignalHandler.h
 *
 *  Created on: 2010-4-24 下午10:04:51
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef SIGNALHANDLER_H_
#define SIGNALHANDLER_H_

#include <ace/Signal.h>
#include <ace/Reactor.h>
#include <ace/Event_Handler.h>

class SignalHandler: ACE_Event_Handler {
public:
    SignalHandler(ACE_Reactor* reactor = ACE_Reactor::instance());

    virtual int handle_signal(int signum, siginfo_t*, ucontext_t *);
};

#endif /* SIGNALHANDLER_H_ */
