/*
 * proactor_echo_server.cpp
 *
 *  Created on: 2010-5-4 下午10:23:20
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "ace/Asynch_IO.h"
#include "ace/Asynch_Acceptor.h"
#include "ace/INET_Addr.h"
#include "ace/Proactor.h"

class EchoService: public ACE_Service_Handler {
public:
    ~EchoService() {
        if (this->handle() != ACE_INVALID_HANDLE)
            ACE_OS::closesocket(this->handle());
    }
    virtual void open(ACE_HANDLE h, ACE_Message_Block&) {
        handle(h);
        if (this->reader_.open(*this) != 0 || this->writer_.open(*this) != 0) {
            ACE_ERROR((LM_ERROR, "%p\n", "open()"));
            delete this;
            return;
        }

        ACE_Message_Block* mb;
        ACE_NEW_NORETURN(mb, ACE_Message_Block(512));
        if (this->reader_.read(*mb, mb->space()) != 0) {
            ACE_ERROR((LM_ERROR, "%p\n", "read()"));
            mb->release();
            delete this;
            return;
        }
    }
    virtual void handle_read_stream(
            const ACE_Asynch_Read_Stream::Result& result) {
        ACE_Message_Block &mb = result.message_block();
        if (!result.success() || result.bytes_transferred() == 0) {
            mb.release();
            delete this;
        } else {
            if (this->writer_.write(mb, mb.length()) != 0) {
                ACE_ERROR((LM_ERROR, "%p\n", "write()"));
                mb.release();
            } else {
                ACE_Message_Block* mblk;
                ACE_NEW_NORETURN(mblk, ACE_Message_Block(512));
                this->reader_.read(*mblk, mblk->space());
            }
        }
    }
    virtual void handle_write_stream(
            const ACE_Asynch_Write_Stream::Result& result) {
        result.message_block().release();
    }

private:
    ACE_Asynch_Read_Stream reader_;
    ACE_Asynch_Write_Stream writer_;
};

int main() {
    ACE_INET_Addr listen_addr(8868);
    ACE_Asynch_Acceptor<EchoService> aio_acceptor;
    if (0 != aio_acceptor.open(listen_addr, 0, // bytes_to_read
            0, // pass_addresses
            ACE_DEFAULT_BACKLOG, 1, // reuse_addr
            0, // proactor
            0)) // validate_new_connection
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "write()"), 1);

    ACE_Proactor::instance()->proactor_run_event_loop();
}
