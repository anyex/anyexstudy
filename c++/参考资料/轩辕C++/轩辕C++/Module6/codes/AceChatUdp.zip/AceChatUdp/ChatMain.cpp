/*
 * ChatMain.cpp
 *
 *  Created on: 2010-4-27 下午02:32:01
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "ChatRoom.h"

int main() {
    ChatRoom room;

    ACE_INET_Addr group(8000, "224.0.0.12");
    if (room.join(group) != -1) {
        room.activate();
        room.startSend();
    }
}
