/*
 * ChatRoom.h
 *
 *  Created on: 2010-4-27 下午02:18:09
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef CHATROOM_H_
#define CHATROOM_H_

#include <ace/Task.h>
#include <ace/SOCK_Dgram_Mcast.h>

class ChatRoom: public ACE_Task_Base {
public:
    int join(const ACE_INET_Addr& group);
    virtual int svc();
    int startSend();

private:
    char buf[512];
    ACE_INET_Addr group;
    ACE_SOCK_Dgram_Mcast sock;
};

#endif /* CHATROOM_H_ */
