/*
 * ChatRoom.cpp
 *
 *  Created on: 2010-4-27 下午02:18:09
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */
#include <iostream>
#include <ace/Log_Msg.h>

#include "ChatRoom.h"

int ChatRoom::join(const ACE_INET_Addr& _group) {
    group = _group;
    if (sock.join(group) == -1)
        ACE_ERROR_RETURN((LM_ERROR,"%p\n", "join"), -1);

    return 0;
}

int ChatRoom::svc() {
    ACE_INET_Addr remoteAddr;
    for (;;) {
        memset(buf, 0, sizeof(buf));
        if (sock.recv(buf, sizeof(buf), remoteAddr) != -1) {
            ACE_DEBUG((LM_DEBUG, "recv msg from %s:%d: %s\n",
                            remoteAddr.get_host_addr(),
                            remoteAddr.get_port_number(), buf));
        } else {
            if (sock.leave(group) == -1)
                ACE_ERROR_RETURN ((LM_ERROR,"%p\n", "leave"), -1);
        }
    }
}

int ChatRoom::startSend() {
    char sendBuf[512];
    for (;;) {
        memset(sendBuf, 0, sizeof(sendBuf));
        std::cin.getline(sendBuf, sizeof(sendBuf));
        if (0 == strcmp("quit", sendBuf)) {
            sock.leave(group);
            break;
        }

        if (sock.send(sendBuf, sizeof(sendBuf)) == -1)
            ACE_ERROR_RETURN ((LM_ERROR,"%p\n", "send"), -1);
    }

    return 0;
}
