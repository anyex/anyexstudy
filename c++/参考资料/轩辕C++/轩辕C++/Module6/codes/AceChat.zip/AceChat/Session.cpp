/*
 * Session.cpp
 *
 *  Created on: 2010-4-27 上午10:49:28
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "Session.h"
#include "ChatRoom.h"

Session::Session() {
    sock = new ACE_SOCK_Stream;
}

Session::~Session() {
    sock->close();
    delete sock;
}

int Session::svc() {
    for (;;) {
        memset(buf, 0, sizeof(buf));
        if (sock->recv(buf, sizeof(buf)) <= 0) {
            ACE_ERROR((LM_ERROR, "%p\n", "recv()"));
            sock->close();
            Room::instance()->leave(this);
        } else {
            Room::instance()->forwardMsg(buf);
        }
    }
    return 0;
}

ACE_SOCK_Stream& Session::socket() {
    return *sock;
}
