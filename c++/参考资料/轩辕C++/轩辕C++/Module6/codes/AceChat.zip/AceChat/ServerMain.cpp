/*
 * ServerMain.cpp
 *
 *  Created on: 2010-4-27 上午11:16:37
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/INET_Addr.h>
#include <ace/Log_Msg.h>

#include "Server.h"

int main() {
    ACE_INET_Addr addr;

    if (addr.set(8868) == -1)
        ACE_ERROR_RETURN((LM_ERROR, "%p\n", "open()"), -1);

    Server s;
    s.start(addr);
}
