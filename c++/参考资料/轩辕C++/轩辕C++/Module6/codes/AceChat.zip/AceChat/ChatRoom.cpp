/*
 * ChatRoom.cpp
 *
 *  Created on: 2010-4-27 上午10:12:39
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "ChatRoom.h"

//ChatRoom* ChatRoom::room = 0;
//
//ChatRoom* ChatRoom::instacne() {
//    if (0 == room)
//        room = new ChatRoom;
//    return room;
//}

//ChatRoom::ChatRoom() {
//}
//
//ChatRoom::ChatRoom(const ChatRoom&) {
//}
//
//ChatRoom& ChatRoom::operator=(const ChatRoom&) {
//    return *this;
//}

void ChatRoom::join(Session* user) {
    users.push_back(user);
}

void ChatRoom::leave(Session* user) {
    std::list<Session*>::iterator it = users.begin();
    for (; it != users.end(); ++it) {
        if (*it == user) {
            user->close();
            delete user;
            users.erase(it++);
            break;
        }
    }
}

void ChatRoom::forwardMsg(const char* buf) {
    std::list<Session*>::iterator it = users.begin();
    while (it != users.end()) {
        if ((*it)->socket().send(buf, strlen(buf)) == -1) {
            leave(*it);
        } else {
            ++it;
        }
    }
}

ChatRoom::~ChatRoom() {
    std::list<Session*>::iterator it = users.begin();
    while (it != users.end()) {
        (*it)->close();
        delete *it;
        users.erase(it++);
    }
}
