/*
 * ChatRoom.h
 *
 *  Created on: 2010-4-27 上午10:12:39
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef CHATROOM_H_
#define CHATROOM_H_

#include <list>

#include <ace/SOCK_Stream.h>
#include <ace/Singleton.h>
#include <ace/Null_Mutex.h>

#include "Session.h"

class ChatRoom {
public:
//    static ChatRoom* instacne();

    void join(Session* user);
    void leave(Session* user);

    void forwardMsg(const char* buf);

    virtual ~ChatRoom();

//private:
//    ChatRoom();
//    ChatRoom(const ChatRoom&);
//    ChatRoom& operator=(const ChatRoom&);

private:
//    static ChatRoom* room;

    std::list<Session*> users;
};

typedef ACE_Singleton<ChatRoom, ACE_Null_Mutex> Room;

#endif /* CHATROOM_H_ */
