/*
 * Server.h
 *
 *  Created on: 2010-4-27 上午10:33:42
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef SERVER_H_
#define SERVER_H_

#include <ace/SOCK_Acceptor.h>

class Server {
public:
    Server();
    void start(const ACE_INET_Addr& addr);

    virtual ~Server();

private:
    ACE_SOCK_Acceptor acceptor;
};

#endif /* SERVER_H_ */
