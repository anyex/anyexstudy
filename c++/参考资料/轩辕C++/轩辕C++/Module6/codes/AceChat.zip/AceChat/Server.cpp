/*
 * Server.cpp
 *
 *  Created on: 2010-4-27 上午10:33:42
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/Log_Msg.h>

#include "Server.h"
#include "ChatRoom.h"
#include "Session.h"

Server::Server() {
}

void Server::start(const ACE_INET_Addr& addr) {
    if (acceptor.open(addr, 1) == -1) {
        ACE_ERROR((LM_ERROR, "%p\n", "open()"));
        return;
    }

    for (;;) {
        Session* user = new Session;
        if (acceptor.accept(user->socket()) == -1) {
            ACE_ERROR((LM_ERROR, "%p\n", "accept()"));
            delete user;
        } else {
            Room::instance()->join(user);
            user->activate();
        }
    }
}

Server::~Server() {
    acceptor.close();
}

