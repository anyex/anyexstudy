/*
 * Session.h
 *
 *  Created on: 2010-4-27 上午10:49:28
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef SESSION_H_
#define SESSION_H_

#include <ace/Task.h>
#include <ace/SOCK_Stream.h>

class Session: public ACE_Task_Base {
public:
    Session();
    virtual ~Session();

    virtual int svc();

    ACE_SOCK_Stream& socket();

private:
    char buf[512];
    ACE_SOCK_Stream* sock;
};

#endif /* SESSION_H_ */
