/*
 * connector_test.cpp
 *
 *  Created on: 2010-4-22 下午10:10:45
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/INET_Addr.h>
#include <ace/SOCK_Connector.h>
#include <ace/SOCK_Stream.h>

#include <iostream>

int main() {
    using namespace std;

    ACE_SOCK_Connector connector;
    ACE_SOCK_Stream peer;
    ACE_INET_Addr peerAddr;

    if (peerAddr.set(80, "xuanyuan-soft.cn") == -1) {
        cerr << "set() error" << endl;
        return 1;
    }

    // 发起阻塞式连接操作
    else if (connector.connect(peer, peerAddr) == -1) {
        cerr << "connect() error" << endl;
        return 1;
    }
    // 接下来执行其它操作...
}
