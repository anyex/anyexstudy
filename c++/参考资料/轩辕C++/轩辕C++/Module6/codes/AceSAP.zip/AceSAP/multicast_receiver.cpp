/*
 * multicast_receiver.cpp
 *
 *  Created on: 2010-4-22 下午11:18:38
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

// 多播接收端
#include <ace/SOCK_Dgram_Mcast.h>
#include <ace/Log_Msg.h>

int main() {
    ACE_INET_Addr mcastAddr(9988, "224.0.0.16");
    ACE_INET_Addr remoteAddr;
    ACE_SOCK_Dgram_Mcast scok;

    if (scok.join(mcastAddr) == -1)
        ACE_ERROR_RETURN ((LM_ERROR,"%p\n", "join"), 1);

    char buf[512];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        if (scok.recv(buf, sizeof(buf), remoteAddr) != -1)
            ACE_DEBUG((LM_DEBUG, "recv msg from %s:%d: %s\n",
                            remoteAddr.get_host_addr(),
                            remoteAddr.get_port_number(), buf));
    }
    if (scok.leave(mcastAddr) == -1)
        ACE_ERROR_RETURN ((LM_ERROR,"%p\n", "leave"), 1);
}
