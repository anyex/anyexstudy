/*
 * unicast_server.cpp
 *
 *  Created on: 2010-4-22 下午11:12:37
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <ace/SOCK_Dgram.h>
#include <ace/INET_Addr.h>
#include <ace/Time_Value.h>
#include <ace/Log_Msg.h>

int main(int argc, char *argv[]) {
    using namespace std;
    ACE_INET_Addr serverAddr(8868);
    ACE_SOCK_Dgram peer(serverAddr);
    char buf[512];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        ACE_INET_Addr remoteAddr;
        ssize_t len = peer.recv(buf, sizeof(buf), remoteAddr);
        if (len > 0) {
            peer.send(buf, len, remoteAddr);
//            ACE_DEBUG((LM_DEBUG, "%s %s\n", "recv", buf));
        }
    }
}
