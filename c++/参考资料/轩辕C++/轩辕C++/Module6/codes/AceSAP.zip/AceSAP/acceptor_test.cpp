/*
 * acceptor_test.cpp
 *
 *  Created on: 2010-4-22 下午10:36:12
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

// 一个简易的 HTTP Server

#include <ace/INET_Addr.h>
#include <ace/SOCK_Acceptor.h>
#include <ace/SOCK_Stream.h>
#include <ace/Mem_Map.h>
#include <ace/Log_Msg.h>

// Return a dynamically allocated path name buffer.
extern char* get_url_pathname(ACE_SOCK_Stream *);

int main() {
    ACE_INET_Addr server_addr;
    ACE_SOCK_Acceptor acceptor;
    ACE_SOCK_Stream peer;

    if (server_addr.set(8868) == -1)
        ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "set()"), 1);
    if (acceptor.open(server_addr) == -1)
        ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "open()"), 1);

    for (;;) {
        if (acceptor.accept(peer) == -1)
            ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "accept()"), 1);
        peer.disable(ACE_NONBLOCK); // Ensure blocking <recv>s.

        char* pathname = get_url_pathname(&peer);
        // 检查 pathname 是否为NULL，略...
        ACE_Mem_Map mapped_file(pathname);
        delete[] pathname;

        if (peer.send_n(mapped_file.addr(), mapped_file.size()) == -1)
            ACE_ERROR_RETURN ((LM_ERROR, "%p\n", "send_n()"), 1);
        peer.close();
    }

    return acceptor.close() == -1 ? 1 : 0;
}

char* get_url_pathname(ACE_SOCK_Stream* peer) {
    static const char* docBase = "./pages";
    char buf[512];
    if (peer->recv(buf, sizeof(buf)) != -1) {
        // request example:
        // GET /index.html HTTP/1.0\r\n
        const char* pos1 = strchr(buf, ' ');
        const char* pos2 = strchr(++pos1, ' ');
        const size_t len = pos2 - pos1;
        const size_t docLen = std::strlen(docBase);

        char* path = new char[len + docLen + 1];
        memcpy(path, docBase, docLen);
        memcpy(path + docLen, pos1, len);
        path[len + docLen] = '\0';
        return path;
    }
    return 0;
}
