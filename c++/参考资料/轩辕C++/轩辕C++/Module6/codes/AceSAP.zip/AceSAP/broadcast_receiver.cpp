/*
 * broadcast_receiver.cpp
 *
 *  Created on: 2010-4-22 下午11:29:00
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

// 广播接收端
#include <ace/SOCK_Dgram_Bcast.h>
#include <ace/Log_Msg.h>

int main() {
    ACE_INET_Addr localAddr(8868);
    ACE_INET_Addr remoteAddr;
    ACE_SOCK_Dgram_Bcast scok(localAddr);

    char buf[512];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        if (scok.recv(buf, sizeof(buf), remoteAddr) != -1)
            ACE_DEBUG((LM_DEBUG, "recv msg from %s:%d: %s\n",
                            remoteAddr.get_host_addr(),
                            remoteAddr.get_port_number(), buf));
    }
}
