/*
 * multicast_sender.cpp
 *
 *  Created on: 2010-4-22 下午11:17:56
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

// 多播发送端
#include <iostream>
#include <ace/SOCK_Dgram_Mcast.h>
#include <ace/Log_Msg.h>

int main() {
    ACE_INET_Addr mcastAddr(9988, "224.0.0.16");
    ACE_INET_Addr localAddr;
    ACE_SOCK_Dgram scok(localAddr);

    char buf[128];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        std::cin.getline(buf, sizeof(buf));
        if (0 == strcmp("quit", buf))
            break;
        if (scok.send(buf, sizeof(buf), mcastAddr) == -1)
            ACE_ERROR_RETURN ((LM_ERROR,"%p\n", "send"), 1);
    }
}
