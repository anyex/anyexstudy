/*
 * unicast_client.cpp
 *
 *  Created on: 2010-4-22 下午11:13:19
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>

#include <ace/SOCK_Dgram.h>
#include <ace/INET_Addr.h>
#include <ace/Time_Value.h>
#include <ace/Log_Msg.h>

int main() {
    ACE_INET_Addr remoteAddr(8868, "127.0.0.1");
    ACE_INET_Addr localAddr;
    ACE_SOCK_Dgram peer(localAddr);

    char buf[128];
    for (;;) {
        memset(buf, 0, sizeof(buf));
        std::cin.getline(buf, sizeof(buf));
        if (0 == strcmp("quit", buf))
            break;
        ssize_t len = peer.send(buf, strlen(buf), remoteAddr);

        memset(buf, 0, sizeof(buf));
        len = peer.recv(buf, sizeof(buf), localAddr);
        if (len > 0)
            ACE_DEBUG((LM_DEBUG, "%s\n", buf));
    }
}
