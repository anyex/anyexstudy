#include <iostream>
#include <boost/tuple/tuple.hpp>

using namespace std;

int main() {
    int i;
    char c;
    double d;
    // 创建 tuple<int&, char&, double&>，或：
    // 调用 make_tuple(ref(i), ref(c), ref(d));
    boost::tie(i, c, d) = boost::tuple<int, char, double>(1, 'A', 0.618);
    cout << d << endl; // 0.618

    // ignore
    char c2;
    boost::tie(boost::tuples::ignore, c2) = std::make_pair(1, 'a');
    cout << c2 << endl;
}
