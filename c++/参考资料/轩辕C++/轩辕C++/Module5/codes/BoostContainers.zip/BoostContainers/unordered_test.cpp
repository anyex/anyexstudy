/*
 * unordered_test.cpp
 *
 *  Created on: 2010-2-28 下午01:16:38
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/unordered_map.hpp>

using namespace std;

template<typename Iter>
void print(Iter first, Iter last) {
    for (; first != last; ++first)
        cout << first->first << ' ' << first->second << endl;
}

int main() {
    boost::unordered_map<string, int> m1;
    m1.insert(make_pair("xuanyuan", 12));
    m1["x1"] = 120;
    m1.insert(make_pair("xuanyuan1", 56));
    m1.insert(make_pair("xuanyuan2", 27));
    m1.insert(make_pair("xuanyuan3", 1234));
    m1["x4"] = 126;
    m1["xAS"] = 129;

    print(m1.begin(), m1.end());

    cout << "m1 size: " << m1.size() << endl;
    const int n = m1.bucket_count();
    for (int i = 0; i < n; ++i)
        cout << "Bucket #" << i << ": " << m1.bucket_size(i) << endl;

    cout << "------------------------------------" << endl;
    typedef boost::unordered_map<string, int>::local_iterator LIter;
    for(LIter it = m1.begin(7); it != m1.end(7); ++it) {
        cout << it->first << ' ' << it->second << endl;
    }

}
