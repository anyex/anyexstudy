#include <iostream>
#include <boost/tuple/tuple_io.hpp>

using namespace std;

int main() {
    boost::tuple<float, int, string> a1(1.0f, 2, string("Howdy folks!"));
    cout << a1 << endl; // (1 2 Howdy folks!)

    //
    boost::tuple<float, int, string> a2(1.0f, 2, string("Howdy folks!"));
    cout << boost::tuples::set_open('[') << boost::tuples::set_close(']')
            << boost::tuples::set_delimiter(',') << a2 << endl;
    //output: [1,2,Howdy folks!]

    boost::tuple<int, int, int> i;
    cin >> i; // inupt i from cin
    cout << i << endl;
    boost::tuple<int, int> j;
    cin >> boost::tuples::set_open('[') >> boost::tuples::set_close(']')
            >> boost::tuples::set_delimiter(':');
    cin >> j; // 接受：[12:9] 之类的格式
    cout << j << endl;

}
