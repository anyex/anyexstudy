/*
 * array_test.cpp
 *
 *  Created on: 2010-2-28 下午12:54:33
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <algorithm>
#include <boost/array.hpp>

using namespace std;

int main() {
    boost::array<int, 5> a1 = {{ 12, 23, 89, 6, 18 }};

    sort(a1.begin(), a1.end());
    copy(a1.begin(), a1.end(), ostream_iterator<int> (cout, " "));
}
