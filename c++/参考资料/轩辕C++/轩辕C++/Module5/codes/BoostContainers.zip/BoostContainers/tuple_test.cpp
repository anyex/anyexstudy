/*
 * tuple_test.cpp
 *
 *  Created on: 2010-2-28 下午12:22:03
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>

#include <boost/tuple/tuple.hpp>

using namespace std;

void f(int(&a)[3]) {
    cout << a[0] << endl;
}

class A {
};

int main() {
    // test for pass array refernce
    int a2[3];
    f(a2);

    using boost::tuple;
    double d = 2.7;
    A a;
    tuple<int, double&, const A&> t(1, d, a);
    const tuple<int, double&, const A&> ct = t;
    //...
    int i = boost::get<0>(t);
    i = t.get<0> (); // ok
    int j = boost::get<0>(ct); // ok
    boost::get<0>(t) = 5; // ok
//    boost::get<0>(ct) = 5; // error, can't assign to const
    //...
    double e = boost::get<1>(t); // ok
    boost::get<1>(t) = 3.14; // ok
//    boost::get<2>(t) = A(); // error, can't assign to const
//    A aa = boost::get<3>(t); // error: index out of bounds
    ++boost::get<0>(t); // ok, can be used as any variable
}
