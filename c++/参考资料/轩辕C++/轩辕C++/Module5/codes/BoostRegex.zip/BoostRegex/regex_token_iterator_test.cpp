/*
 * regex_token_iterator_test.cpp
 *
 *  Created on: 2010-3-1 上午12:24:08
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/regex.hpp>

using namespace std;

int main() {
    using boost::regex;
    string s("This is a string of tokens");
    boost::regex re("\\s+");
    boost::sregex_token_iterator i(s.begin(), s.end(), re, -1);
    boost::sregex_token_iterator j;

    unsigned count = 0;
    while (i != j) {
        cout << *i++ << endl;
        count++;
    }
    cout << "There were " << count << " tokens found." << endl;
}
