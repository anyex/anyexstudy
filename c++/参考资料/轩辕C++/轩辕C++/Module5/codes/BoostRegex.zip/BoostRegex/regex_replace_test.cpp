/*
 * regex_replace_test.cpp
 *
 *  Created on: 2010-3-1 上午12:07:24
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/regex.hpp>

using namespace std;

int main() {
    using boost::regex;
    regex e1("([TQV])|(\\*)|(@)");
    string replaceFmt("(\\L?1$&)(?2+)(?3#)");
    string src("guTdQhV@@g*b*");
    cout << "before replaced: " << src << endl;
    // 注意：format_all
    string newStr1 = regex_replace(src, e1, replaceFmt, boost::match_default
            | boost::format_all);
    cout << "after replaced: " << newStr1 << endl;

    // 注意：format_default
    string newStr2 = regex_replace(src, e1, replaceFmt, boost::match_default
            | boost::format_default);
    cout << "after replaced: " << newStr2 << endl;

    // 另一种形式的调用
    ostream_iterator<char> oi(cout);
    regex_replace(oi, src.begin(), src.end(), e1, replaceFmt,
            boost::match_default | boost::format_all);
}
