/*
 * match_results_test.cpp
 *
 *  Created on: 2010-2-28 下午11:47:52
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/regex.hpp>

using namespace std;

int main() {
    using boost::regex;
    regex e1("\\bT\\w+\\b ([[:xdigit:]]+)");

    string s("Time ef09,Todo 001");
    boost::smatch m;

    bool b = boost::regex_search(s, m, e1, boost::match_all);
    cout << b << endl;

    const int n = m.size();
    for (int i = 0; i < n; ++i) {
        cout << "matched " << i << " position: " << m.position(i) << ", ";
        cout << "length: " << m.length(i) << ", str: ";
        cout << m.str(i) << endl;
    }

}
