/*
 * Main.cpp
 *
 *  Created on: 2010-2-20 下午03:18:06
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <iomanip>

#include <boost/regex.hpp>

using namespace std;

int main(int argc, const char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " regex-str" << endl;
        return 1;
    }

    boost::regex e(argv[1], boost::regex::icase);
    cout << "subexpressions: " << e.mark_count() << endl;
    string line;
    while (getline(cin, line)) {
        boost::match_results<string::const_iterator> m;
        if (boost::regex_search(line, m, e, boost::match_default)) {
            const int n = m.size();
            for (int i = 0; i < n; ++i) {
                cout << m[i] << ' ';
            }
            cout << endl;
        } else {
            cout << setw(line.size()) << setfill('-') << '-' << right << endl;
        }
    }
}
