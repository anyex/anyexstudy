/*
 * regex_test.cpp
 *
 *  Created on: 2010-2-28 下午11:33:31
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/regex.hpp>

using namespace std;

int main() {
    using boost::regex;
    regex e1;
    e1 = "^[[:xdigit:]]*$";
    cout << e1.str() << endl;
    cout << e1.mark_count() << endl; // 1

    regex e2("\\b\\w+(?=ing)\\b.{2,}?([[:alpha:]]*)$", regex::perl
            | regex::icase | regex::save_subexpression_location);
    cout << e2.str() << endl;
    cout << e2.mark_count() << endl; // 2

    // 如果regex e2 未设save_subexpression_location
    // subexpression()将会抛出异常
    pair<regex::const_iterator, regex::const_iterator> sub1 =
            e2.subexpression(1);
    string sub1Str(sub1.first, ++sub1.second);
    cout << sub1Str << endl;
}
