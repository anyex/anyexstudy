/*
 * regex_iterator_test.cpp
 *
 *  Created on: 2010-3-1 上午12:17:33
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/regex.hpp>

using namespace std;

int main() {
    using boost::regex;
    regex e("(a+).+?", regex::icase);

    string s("ann abb aaat");

    boost::sregex_iterator it1(s.begin(), s.end(), e);
    boost::sregex_iterator it2; // 结束迭代器

    for (; it1 != it2; ++it1) {
        boost::smatch m = *it1;
        cout << m << endl;
    }
}
