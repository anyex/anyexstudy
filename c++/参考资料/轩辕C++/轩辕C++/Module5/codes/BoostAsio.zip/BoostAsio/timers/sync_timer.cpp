/*
 * sync_timer.cpp
 *
 *  Created on: 2010-3-16 下午05:59:21
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

int main() {
    boost::asio::io_service io;
    boost::asio::deadline_timer t(io,
        boost::posix_time::seconds(5));
    t.wait();

    std::cout << "Hello, world!\n";

    return 0;
}
