/*
 * udp_sync_client.cpp
 *
 *  Created on: 2010-3-16 下午04:54:49
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>

#include <boost/asio.hpp>

using namespace std;

using boost::asio::ip::udp;

int main(int argc, char* argv[]) {
    try {
        boost::asio::io_service service; // #1

        udp::resolver resolver(service); // #2
        udp::resolver::query query(udp::v4(), "localhost", "8868"); // #3
        udp::endpoint receiverEndpoint = *resolver.resolve(query); // #4

        //        udp::socket socket(service);
        //        socket.open(udp::v4()); // #5

//        udp::endpoint receiverEndpoint(boost::asio::ip::address::from_string("192.168.0.101"), 51179);

        udp::socket socket(service, udp::v4());// #5
        char buf[512];
        for (;;) {
            memset(buf, 0, 512);
            cin.getline(buf, 512);
            socket.send_to(boost::asio::buffer(buf, strlen(buf)),
                    receiverEndpoint); // #6
            memset(buf, 0, 512);
            udp::endpoint senderEndpoint; // #7
            socket.receive_from(boost::asio::buffer(buf), senderEndpoint); // #8
            cout << buf << endl;
        }
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
