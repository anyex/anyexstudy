/*
 * udp_sync_server.cpp
 *
 *  Created on: 2010-3-16 下午04:44:10
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>

#include <boost/asio.hpp>

using namespace std;

using boost::asio::ip::udp;

int main() {
    try {
        boost::asio::io_service service; // #1
        udp::socket socket(service, udp::endpoint(udp::v4(), 8868)); //#2

        char buf[512];
        for (;;) {
            memset(buf, 0, 512);
            udp::endpoint remoteEndpoint; // #3
            boost::system::error_code error;
            size_t len = socket.receive_from(boost::asio::buffer(buf),
                    remoteEndpoint, 0, error);//#4
            if (error && error != boost::asio::error::message_size)
                throw boost::system::system_error(error);

            boost::system::error_code ignoredError;
            socket.send_to(boost::asio::buffer(buf, len), remoteEndpoint, 0,
                    ignoredError); // #5
        }
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
