/*
 * tcp_sync_resolve.cpp
 *
 *  Created on: 2010-3-16 下午12:08:17
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/asio.hpp>

using namespace std;

using boost::asio::ip::tcp;

int main(int argc, char* argv[]) {

    // 1, 创建io_service对象
    boost::asio::io_service io_service;

    // 2, 创建resolver对象关联到io_service对象
    tcp::resolver resolver(io_service);

    for (;;) {
        try {
            string host, port;
            cin >> host >> port;
            // 3, 创建一个查询对象
            tcp::resolver::query query(host, port);

            // 4, 用resolver对象和查询对象获取可用服务器地址
            tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
            tcp::resolver::iterator end;

            // 5, 创建tcp::socket对象，关联到io_service
            tcp::socket socket(io_service);
            // 6, socket对象发起到服务器端的同步连接操作
            boost::system::error_code error =
                    boost::asio::error::host_not_found;
            while (endpoint_iterator != end) {
                cout << endpoint_iterator->endpoint() << endl;
                socket.close();
                socket.connect(*endpoint_iterator++, error);
            }
            if (error) // 如果没有一个地址能连接成功，则抛出异常
                throw boost::system::system_error(error);
        } catch (std::exception& e) {
            std::cerr << e.what() << std::endl;
        }
    }

    return 0;
}
