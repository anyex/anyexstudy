/*
 * tcp_sync_server.cpp
 *
 *  Created on: 2010-3-16 上午10:50:47
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <fstream>
#include <sstream>

#include <boost/asio.hpp>

using namespace std;

using boost::asio::ip::tcp;

const char* serviceList = "\n\t       Services\n"
    "\t**************************\n"
    "\t[1] Get current time.\n"
    "\t[2] Who's online.\n"
    "\t[3] Get system info.\n"
    "\t**************************\n\n"
    "Please pick a service[1-3]: ";

ifstream fin;

void getResult(const string& cmdPrefix, const char* outputFile, string& res) {
    // cmd == "w > who"
    string cmd(cmdPrefix + outputFile);
    system(cmd.c_str());

    fin.open(outputFile);
    if (fin) {
        ostringstream os;
        os << fin.rdbuf();
        res = os.str();
    }

    if (fin.is_open()) {
        fin.close();
    }

}

string getServiceContent(const int& select) {
    string res;
    switch (select) {
    case 1: {
        time_t t = time(0);
        res = ctime(&t);
        break;
    }
    case 2:
        getResult("w > ", "who", res);
        break;
    case 3:
        getResult("uname -a > ", "uname", res);
        break;
    default:
        res = "Sorry, no such service.\n";
        break;
    }

    return res;
}

int main() {
    try {
        boost::asio::io_service io_service; // #1
        tcp::acceptor acceptor(io_service, tcp::endpoint(tcp::v4(), 8868)); // #2
        for (;;) {
            tcp::socket socket(io_service); // #3
            acceptor.accept(socket); // #4
            // 1, send service list to client
            boost::system::error_code ignored_error;
            boost::asio::write(socket, boost::asio::buffer(serviceList),
                    boost::asio::transfer_all(), ignored_error);

            // 2, receive selection from client
            char selection[20];
            size_t n = socket.read_some(boost::asio::buffer(selection),
                    ignored_error);
            // 3, send response
            string response = getServiceContent(atoi(selection));
            boost::asio::write(socket, boost::asio::buffer(response),
                    boost::asio::transfer_all(), ignored_error);
        } // #6
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }
    return 0;
}
