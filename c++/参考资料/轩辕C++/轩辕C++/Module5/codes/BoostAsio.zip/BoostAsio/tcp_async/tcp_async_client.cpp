/*
 * tcp_async_client.cpp
 *
 *  Created on: 2010-3-16 下午04:00:37
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>

using namespace std;

using namespace boost::asio::ip;

class Client {
public:
    Client(boost::asio::io_service& service,
            tcp::resolver::iterator endpointIterator) :
        sock(service) {
        tcp::endpoint endpoint = *endpointIterator;
        sock.async_connect(endpoint, boost::bind(&Client::handleConnect, this,
                boost::asio::placeholders::error, ++endpointIterator));
    }
private:
    void handleConnect(const boost::system::error_code& error,
            tcp::resolver::iterator endpointIterator) {
        if (!error) {
            memset(buf, 0, 512);
            cin.getline(buf, BUF_SIZE);
            boost::asio::async_write(sock,
                    boost::asio::buffer(buf, strlen(buf)), boost::bind(
                            &Client::handleWrite, this,
                            boost::asio::placeholders::error));
        } else if (endpointIterator != tcp::resolver::iterator()) {
            sock.close();
            tcp::endpoint endpoint = *endpointIterator;
            sock.async_connect(endpoint, boost::bind(&Client::handleConnect,
                    this, boost::asio::placeholders::error, ++endpointIterator));
        }
    }
    void handleRead(const boost::system::error_code& error) {
        if (!error) {
            cout << buf << endl; // print received message
            memset(buf, 0, 512);
            cin.getline(buf, BUF_SIZE);
            boost::asio::async_write(sock,
                    boost::asio::buffer(buf, strlen(buf)), boost::bind(
                            &Client::handleWrite, this,
                            boost::asio::placeholders::error));
        }
    }
    void handleWrite(const boost::system::error_code& error) {
        if (!error) {
            memset(buf, 0, 512); // 注意：重置buf
            sock.async_read_some(boost::asio::buffer(buf),
                    boost::bind(&Client::handleRead, this,
                            boost::asio::placeholders::error));
        }
    }

private:
    tcp::socket sock;
    enum {
        BUF_SIZE = 512
    };
    char buf[BUF_SIZE];
};

int main() {
    try {
        boost::asio::io_service service;

        tcp::resolver resolver(service);
        tcp::resolver::query query("localhost", "8868");
        tcp::resolver::iterator iterator = resolver.resolve(query);

        tcp::endpoint addr(address::from_string("127.0.0.1"), 8868);

        Client client(service, iterator);

        service.run();
    } catch (std::exception& e) {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}
