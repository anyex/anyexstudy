/*
 * make_shared_test.cpp
 *
 *  Created on: 2010-3-1 下午09:35:45
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>

using namespace std;

struct D {
    D() {
        cout << "D::D()" << endl;
    }
    D(int k, double d) {
        cout << "D::D(int k, double d)" << endl;
    }
    ~D() {
        cout << "D::~D()" << endl;
    }
};

struct E {
    E(string s) {
        cout << "E::E(string s)" << endl;
    }

    ~E() {
        cout << "E::~E()" << endl;
    }
};

int main() {
    // 调用D的默认构造函数：D()
    boost::shared_ptr<D> dp1 = boost::make_shared<D>();

    // 调用D的非默认构造函数：D(int, double)
    boost::shared_ptr<D> dp2 = boost::make_shared<D>(12, .618);

    // 调用E的构造函数：E(string)
    boost::shared_ptr<E> ep = boost::make_shared<E>("test");
}
