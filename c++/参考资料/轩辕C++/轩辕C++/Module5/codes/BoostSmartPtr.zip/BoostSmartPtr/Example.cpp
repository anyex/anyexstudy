/*
 * Example.cpp
 *
 *  Created on: 2010-3-1 下午10:01:18
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */
#include <iostream>

#include "Example.h"

class Example::implementation {
public:
    ~implementation() {
        std::cout << "destroying implementation\n";
    }
};

Example::Example() :
    _imp(new implementation) {
}

void Example::do_something() {
    std::cout << "use_count() is " << _imp.use_count() << "\n";
}
