/*
 * Example.h
 *
 *  Created on: 2010-3-1 下午10:01:18
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#ifndef EXAMPLE_H_
#define EXAMPLE_H_

#include <boost/shared_ptr.hpp>

class Example {
public:
    Example();
    void do_something();
private:
    class implementation;

    // hide implementation details
    boost::shared_ptr<implementation> _imp;
};

#endif /* EXAMPLE_H_ */
