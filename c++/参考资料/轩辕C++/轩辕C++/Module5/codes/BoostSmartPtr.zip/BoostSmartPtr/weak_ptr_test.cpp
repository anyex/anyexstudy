/*
 * weak_ptr_test.cpp
 *
 *  Created on: 2010-3-1 下午08:48:34
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

using namespace std;

struct A {
    A() {
        cout << "A::A()" << endl;
    }

    ~A() {
        cout << "A::~A()" << endl;
    }

    void f() {
        cout << "A::f()" << endl;
    }
};

int main() {
    boost::shared_ptr<int> sp(new int(128));
    cout << ++*sp << endl; // 129
    boost::shared_ptr<int> sp2(sp);
    cout << sp2.use_count() << endl;

    boost::weak_ptr<int> wp(sp2);
    cout << wp.use_count() << endl;

    cout << *wp.lock() << endl; // 129

    boost::shared_ptr<A> ap(new A);
    ap->f();

    cout << "--------------------------------" << endl;
}
