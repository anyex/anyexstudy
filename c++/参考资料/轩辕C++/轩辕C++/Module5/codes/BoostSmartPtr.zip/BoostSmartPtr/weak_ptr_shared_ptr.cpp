/*
 * weak_ptr_shared_ptr.cpp
 *
 *  Created on: 2010-3-1 下午09:51:26
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>
using namespace std;

struct B;
struct A {
    A() {
        cout << "A::A()" << endl;
    }

    ~A() {
        cout << "A::~A()" << endl;
    }

    boost::shared_ptr<B> pb;
};

struct B {
    B() {
        cout << "B::B()" << endl;
    }

    ~B() {
        cout << "B::~B()" << endl;
    }

   // boost::shared_ptr<A> pa;
    boost::weak_ptr<A> pa;
};

int main() {
    boost::shared_ptr<B> sb(new B);
    boost::shared_ptr<A> sa(new A);

    sb->pa = sa;
    sa->pb = sb;

    cout << "--------------------------------" << endl;
}
