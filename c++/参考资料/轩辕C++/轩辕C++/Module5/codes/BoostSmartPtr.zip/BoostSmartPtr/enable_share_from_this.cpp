/*
 * enable_share_from_this.cpp
 *
 *  Created on: 2010-3-1 下午09:43:07
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

using namespace std;

class A;
void func(boost::shared_ptr<A> p) {
    //...
}

class A: public boost::enable_shared_from_this<A> {
public:
    void f() {
        func(shared_from_this());
    }
};

int main() {

}

