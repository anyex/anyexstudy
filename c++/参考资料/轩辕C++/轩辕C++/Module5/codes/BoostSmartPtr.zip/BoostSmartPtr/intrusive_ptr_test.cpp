/*
 * intrusive_ptr_test.cpp
 *
 *  Created on: 2010-3-1 下午09:23:16
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/intrusive_ptr.hpp>

using namespace std;

class RefCounter {
    int refCount;

public:
    RefCounter() :
        refCount() {
    }

    virtual ~RefCounter() {
    }

    int getRefCount() const {
        return refCount;
    }

    friend void intrusive_ptr_add_ref(RefCounter* p) {
        ++p->refCount;
    }

    friend void intrusive_ptr_release(RefCounter* p) {
        if (--p->refCount == 0)
            delete p;
    }
};

class D: public RefCounter {
public:
    D() {
        cout << "D::D()" << endl;
    }

    ~D() {
        cout << "D::~D()" << endl;
    }
};

int main() {
    D* dp = new D;
    boost::intrusive_ptr<D> dp1(dp);

    {
        boost::intrusive_ptr<D> dp2(dp);
        cout << dp2->getRefCount() << endl;
    }
    cout << dp1->getRefCount() << endl;
}
