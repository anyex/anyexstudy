/*
 * pimpl_test.cpp
 *
 *  Created on: 2010-3-1 下午10:05:43
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include "Example.h"

int main() {
    Example a;
    a.do_something();
    Example b(a);
    b.do_something();
    Example c;
    c = a;
    c.do_something();
    return 0;
}
