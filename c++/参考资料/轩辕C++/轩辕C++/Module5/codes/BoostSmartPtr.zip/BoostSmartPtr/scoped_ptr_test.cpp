/*
 * scoped_ptr_test.cpp
 *
 *  Created on: 2010-3-1 下午08:48:34
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/scoped_ptr.hpp>

using namespace std;

struct A {
    A() { cout << "A::A()" << endl; }

    ~A() { cout << "A::~A()" << endl; }

    void f() { cout << "A::f()" << endl; }
};

int main() {
    boost::scoped_ptr<int> sp(new int(128));
    cout << ++*sp << endl; // 129
//    boost::scoped_ptr<int> sp2(sp); // Error

    boost::scoped_ptr<A> ap(new A);
    ap->f();

    cout << "--------------------------------" << endl;
}
