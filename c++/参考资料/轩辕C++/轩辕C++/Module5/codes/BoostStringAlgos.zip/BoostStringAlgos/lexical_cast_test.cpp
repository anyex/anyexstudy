/*
 * lexical_cast_test.cpp
 *
 *  Created on: 2010-2-28 下午02:54:02
 *      Author: kwarph
 *         Web: http://www.xuanyuan-soft.cn
 *        Mail: kwarph@gmail.com
 */

#include <iostream>
#include <boost/lexical_cast.hpp>

using namespace std;

int main() {
    string s("3.14e12");
    double d = boost::lexical_cast<double>(s);
    cout << d << endl; // 3.14e+12

    try {
        int i = strtol("ff", 0, 16);
        cout << i << endl; // 255

        // throws bad_lexical_cast
        int i2 = boost::lexical_cast<int>("ff");
        cout << i2 << endl;
    } catch (boost::bad_lexical_cast& e) {
        cout << e.what() << endl;
    }

    string ns = boost::lexical_cast<string>(0xff);
    cout << ns << endl; // 255
}
