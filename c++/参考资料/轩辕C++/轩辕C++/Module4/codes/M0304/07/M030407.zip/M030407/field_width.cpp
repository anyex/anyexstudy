/*
 * field_width.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include "ios_test.h"

using namespace std;

void fieldWidth() {
    cout.width(8);
    cout.fill('*');
    cout.setf(ios::internal, ios::adjustfield);
    cout << -12 << endl;
    cout << -12 << endl;
}
