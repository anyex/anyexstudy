/*
 * stream_state.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include <fstream>
#include "ios_test.h"
using namespace std;

void iosState() {
    ifstream fin("input.cpp");
    if (!fin) {
        cerr << "open file failed.\n";
        return;
    }

    char c;
    while (fin.get(c))
        cout.put(c);
}
