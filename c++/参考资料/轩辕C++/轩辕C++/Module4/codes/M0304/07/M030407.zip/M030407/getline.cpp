/*
 * getline.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */
#include <iostream>
#include "ios_test.h"
using namespace std;

void getTest() {
    char ca1[8];
    cin.get(ca1, 8, 'u');
    cout << ca1 << endl;
    char ca2[8];
    cin.get(ca2, 8, 'w');
    cout << ca2 << endl;
}

void getlineTest() {
    char ca3[8];
    cin.getline(ca3, 8, 'u');
    cout << ca3 << endl;
    char ca4[8];
    cin.get(ca4, 8, 'w');
    cout << ca4 << endl;
}

void getLineString() {
    string line;
    while (getline(cin, line))
        cout << line << endl;
}

void getsTest() {
    //    getTest();
    //    getlineTest();
    getLineString();
}
