/*
 * sstream.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstdio>
#include "ios_test.h"
using namespace std;

void sstreamTest() {
    ostringstream os("Date: ", ios::ate);
    //    ostringstream os("Date: "); // 与上行的输出的区别？
    os << setw(4) << setfill('0') << 121 << '-' << setw(2);
    os << 6 << '-' << setw(2) << 8;
    cout << os.str() << endl;
    os.str(""); // 清空os的内容

    char ds[18];
    sprintf(ds, "Date: %04d-%02d-%02d", 121, 6, 8);
    cout << ds << endl;

    string line("number 0xff");
    istringstream is(line);
    string s;
    is >> s;
    cout << "First word is a string: " << s << endl;
    int n;
    is >> hex >> n; // 如果不要 std::hex 操纵符 ？
    cout << hex << showbase << "Second word is a number: " << n << endl;
}
