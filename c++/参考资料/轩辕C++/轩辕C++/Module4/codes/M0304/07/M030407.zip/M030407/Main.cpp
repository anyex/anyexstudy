/*
 * Main.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include "ios_test.h"

int main(int argc, const char* argv[]) {
//    fieldWidth();
//    fileCopy(argc, argv);
//    fmtfield();
//    getsTest();
//    igonreTest();
//    inputFailed();
//    manipTest();
//    sstreamTest();
//    iosState();
//    virtualInput();
    my_wc(argc, argv);
}

