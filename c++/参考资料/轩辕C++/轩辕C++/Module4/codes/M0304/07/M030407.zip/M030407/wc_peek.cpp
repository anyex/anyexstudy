/*
 * wc_peek.cpp
 *
 *  Created on: 2010-2-3
 *      Author: kwarph
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include "ios_test.h"

using namespace std;

void my_wc(int argc, const char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " input_file\n";
        return;
    }

    ifstream fin(argv[1]);
    if (fin) {
        int cc = 0, cw = 0, cl = 0;
        char c;
        while (fin.get(c)) {
            ++cc;
            if (isspace(c)) {
                if (!isspace(fin.peek()))
                    ++cw;

                if ('\n' == c)
                    ++cl;
            }
        }
        cout << setw(4) << right << cl << ' ';
        cout << setw(4) << right << cw << ' ';
        cout << setw(4) << right << cc << ' ';
        cout << argv[1] << endl;
    } else {
        cerr << "open file " << argv[1] << " failed.\n";
    }
}
