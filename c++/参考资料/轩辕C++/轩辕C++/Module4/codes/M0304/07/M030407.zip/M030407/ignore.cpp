/*
 * ignore.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include "ios_test.h"

using namespace std;

void igonreTest() {
    //    cin.ignore();
    char ca1[12];
    cin.ignore().getline(ca1, 12, 'q');
    cout << ca1 << endl;

    char ca2[12];
    cin.ignore(3).getline(ca2, 12, 'q');
    cout << ca2 << endl;

    char ca3[12];
    cin.ignore(6, 'x').getline(ca3, 12, 'q');
    cout << ca3 << endl;
}

