/*
 * ios_test.h
 *
 *  Created on: 2010-2-3
 *      Author: kwarph
 */

#ifndef IOS_TEST_H_
#define IOS_TEST_H_

void fieldWidth();
void fileCopy(int argc, const char* argv[]);
void fmtfield();
void getsTest();
void igonreTest();
void inputFailed();
void manipTest();
void sstreamTest();
void iosState();
void virtualInput();
void my_wc(int argc, const char* argv[]);

#endif /* IOS_TEST_H_ */
