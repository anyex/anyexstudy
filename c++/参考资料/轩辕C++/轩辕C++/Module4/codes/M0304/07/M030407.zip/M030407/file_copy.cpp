/*
 * file_copy.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include <fstream>

#include "ios_test.h"

using namespace std;

void fileCopy(int argc, const char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " src_file dest_file.\n";
        return;
    }

    ifstream fin(argv[1]);
    if (!fin) {
        cerr << "open input file " << argv[1] << " failed.\n";
        return;
    }

    ofstream fout(argv[2]);
    if (!fout) {
        cerr << "open output file " << argv[2] << " failed.\n";
        return;
    }

    char c;
    //    while (fin.get(c))
    //        fout.put(c);

    while (fin >> c)
        fout << c;
}
