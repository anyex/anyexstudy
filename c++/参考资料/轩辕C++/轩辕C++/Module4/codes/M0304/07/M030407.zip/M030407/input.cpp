/*
 * input.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include "ios_test.h"
using namespace std;

void skipWhitespace() {
    string s;
    cin >> s;
    cout << s << endl;
}

void cinFail() {
    int i;
    cout << "a integer number: ";
    cin >> i;
    cout << i << endl;

    char ca[5];
    cout << "a c-string with 4 chars: ";
    cin.width(5);
    cin >> ca;
    cout << ca << endl;
}

void inputFailed() {
    skipWhitespace();
    cinFail();
}
