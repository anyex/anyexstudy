/*
 * fmtflags.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include "ios_test.h"

using namespace std;

void fmtfield() {
    ios::fmtflags oldfmt = cout.flags(); // 保存当前的flags

    ios::fmtflags newfmt = ios::showbase | ios::left | ios::hex
            | ios::scientific | ios::uppercase;
    cout.flags(newfmt); // 设置新的flags
    cout << 255 << ' ' << 12.09 << endl;

    cout.flags(oldfmt); // 恢复到原先的格式状态
    cout << 255 << ' ' << 12.09 << endl;

    cout.flags(cout.flags() | ios::scientific);
    cout << 12.09 << endl;

    cout.setf(ios::boolalpha);
    cout << true << endl;
}
