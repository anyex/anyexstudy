/*
 * virtual_output.cpp
 *
 *  Created on: 2010-2-2
 *      Author: kwarph
 */

#include <iostream>
#include "ios_test.h"
using namespace std;

struct B {
    virtual ostream& output(ostream& os) const = 0;
};

ostream& operator<<(ostream& os, const B& b) {
    return b.output(os);
}

class D1: public B {
    int k;
public:
    D1() :
        k() {
    }

    virtual ostream& output(ostream& os) const {
        os << "D1: k=" << k;
        return os;
    }
};

class D2: public B {
    int m;
public:
    D2() :
        m() {
    }

    virtual ostream& output(ostream& os) const {
        os << "D1: m=" << m;
        return os;
    }
};
void virtualInput() {
    D1 d;
    cout << d << endl;
    D2 d2;
    cout << d2 << endl;
}
