/*
 * indirect_array_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include "utils.h"
using namespace std;

int main() {
    size_t idx[] = { 9, 1, 12, 3, 6 };
    valarray<size_t> index(idx, 5);

    int a[16] = { 18, 2, 24, 12, 8, 93, 123, 23, 88, 99 };
    valarray<int> va(a, 16);
    print(va);

    valarray<int> va2 = va[index];
    print(va2);
}
