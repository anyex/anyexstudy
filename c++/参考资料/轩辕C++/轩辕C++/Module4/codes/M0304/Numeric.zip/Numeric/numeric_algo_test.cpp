/*
 * numeric_algo_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include <numeric>
#include <iterator>

#include "utils.h"
using namespace std;

int main() {
    int a[] = { 12, 23, 8, 51 };
    int b[] = { 2, 6, 11, 61 };
    int sum = accumulate(a, a + 4, 0); // 94
    cout << sum << endl;

    int prod = inner_product(a, a + 4, b, 0); // 3361
    cout << prod << endl;

    int c[4];
    partial_sum(a, a + 4, c); // 12 35 43 94
    copy(c, c + 4, ostream_iterator<int> (cout, " "));
    cout << endl;

    adjacent_difference(a, a + 4, c); // 12 11 -15 43
    copy(c, c + 4, ostream_iterator<int> (cout, " "));
    cout << endl;
}
