/*
 * utils.h
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <iostream>
#include <valarray>

template<typename T>
void print(const std::valarray<T>& v) {
    const int n = v.size();
    for (size_t i = 0; i < n; ++i) {
        std::cout << v[i] << ' ';
    }
    std::cout << std::endl;
}

#endif /* UTILS_H_ */
