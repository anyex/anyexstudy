/*
 * slice_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include "utils.h"
using namespace std;

int main() {
    int a[16] = { 18, 2, 24, 12, 8, 93, 123, 23 };
    valarray<int> va(a, 16);

    valarray<int> va2 = va[slice(0, 4, 2)];
    print(va2);

    // mask_array
    // 返回子集：va中大于7的元素
    valarray<int> va3 = va[va > 12];
    print(va3);

    // 返回： va[0], va[3], va[5]
    bool ba[] = { true, false, false, true, false, true };
    valarray<bool> mask(ba, 6);
    valarray<int> va4 = va[mask];
    print(va4);
}
