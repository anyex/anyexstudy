/*
 * random_number_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */
#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
    srand((unsigned) time(0));

    int rd = 0;
    for (int i = 0; i < 10; ++i) {
        // rd = rand() % 100;
        rd = int((double(rand()) / RAND_MAX) * 100);
        cout << rd << ' ';
    }
    cout << endl;
}
