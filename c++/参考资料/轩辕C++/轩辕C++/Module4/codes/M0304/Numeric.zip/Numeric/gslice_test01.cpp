/*
 * gslice_test01.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include "utils.h"
using namespace std;

int main() {
    valarray<int> va(14);
    const int n = va.size();
    for (int i = 0; i < n; ++i)
        va[i] = i;

    valarray<size_t> length(2);
    length[0] = 2;
    length[1] = 3;

    valarray<size_t> stride(2);
    stride[0] = 8;
    stride[1] = 2;

    valarray<int> va2 = va[gslice(1, length, stride)];
    print(va2);
}
