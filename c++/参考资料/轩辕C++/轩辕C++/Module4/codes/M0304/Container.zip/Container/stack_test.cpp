/*
 * stack_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */
#include <iostream>
#include <stack>
#include <vector>
#include "utils.h"

using namespace std;

int main() {
    stack<int> s;
    s.push(12);
    s.push(23);
    s.push(66);

    while (!s.empty()) {
        cout << s.top() << ' ';
        s.pop();
    }
    cout << endl;

    vector<int> v(6);
    v[0] = 12;
    v[v.size() - 1] = 88;
    stack<int, vector<int> > s2(v);

    while (!s2.empty()) {
        cout << s2.top() << ' ';
        s2.pop();
    }
    cout << endl;
}
