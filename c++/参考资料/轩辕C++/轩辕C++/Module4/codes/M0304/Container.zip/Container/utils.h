/*
 * utils.h
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <iostream>
#include <map>

// Print sequence containers
template<typename Container>
void print(const std::string& s, const Container& c) {
    typename Container::const_iterator it = c.begin();
    std::cout << s;
    for (; it != c.end(); ++it)
        std::cout << *it << ' ';
    std::cout << std::endl;
}

// Print map
template<typename K, typename V>
void print(const std::string& s, const std::map<K, V>& c) {
    std::cout << s << std::endl;
    typename std::map<K, V>::const_iterator it = c.begin();
    for (; it != c.end(); ++it)
        std::cout << it->first << ' ' << it->second << std::endl;
}

// Print multimap
template<typename K, typename V>
void print(const std::string& s, const std::multimap<K, V>& c) {
    std::cout << s << std::endl;
    typename std::map<K, V>::const_iterator it = c.begin();
    for (; it != c.end(); ++it)
        std::cout << it->first << ' ' << it->second << std::endl;
}
template<typename T>
void print(const std::string& s, T a[], const int& len) {
    std::cout << s;
    for (int i = 0; i < len; ++i)
        std::cout << a[i] << ' ';
    std::cout << std::endl;
}

#endif /* UTILS_H_ */
