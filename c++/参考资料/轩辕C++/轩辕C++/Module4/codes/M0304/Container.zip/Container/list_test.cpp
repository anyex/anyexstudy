/*
 * list_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include "utils.h"

using namespace std;

int main() {

    // constructure
    int a[] = { 12, 23, 56, 89, 7, 65 };
    list<int> ls1(a, a + 6);
    //    list<int> ls1(a, &a[6]);
    print("ls1: ", ls1);

    list<int> ls2;
    ls2.push_back(6);
    ls2.push_back(23);
    ls2.push_back(46);
    print("ls2: ", ls2);

    list<int> ls3(6, 66);
    print("ls3: ", ls3);

    // sort & merge
    ls1.sort();
    print("ls1: ", ls1);
    ls3.merge(ls1);
    print("ls3: ", ls3);
    cout << std::boolalpha << ls1.empty() << endl;

    // splice
    ls2.splice(++ls2.begin(), ls3);
    print("ls2: ", ls2);
    cout << std::boolalpha << ls3.empty() << endl;

    // remove & remove_if
    list<int> ls4(ls2);
    print("ls4: ", ls4);
    ls4.remove(23);
    print("ls4: ", ls4);

    ls4.remove_if(bind2nd(less<int> (), 30));
    print("ls4: ", ls4);

    // unique
    ls4.unique();
    print("ls4: ", ls4);

    // reverse
    ls4.reverse();
    print("ls4: ", ls4);
}
