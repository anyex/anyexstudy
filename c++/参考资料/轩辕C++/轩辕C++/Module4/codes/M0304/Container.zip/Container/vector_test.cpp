/*
 * vector.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 12, 23, 56, 78, 20 };
    vector<int> v2(a, a + 3);
    cout << v2.size() << endl;
    print("v2: ", v2);

    vector<int> v3(v2.begin(), v2.end() - 2);
    print("v3: ", v3);

    vector<int> v1;

    // append
    v1.push_back(12);
    v1.push_back(16);
    v1.push_back(18);

    // access
    cout << v1[2] << endl;
    cout << *(v1.begin() + 1) << endl;
    try {
        v1.at(8);
    } catch (const exception& e) {
        cout << e.what() << endl;
    }

    v1[0] += 23;
    cout << v1[0] << endl;
    cout << "v1.capacity: " << v1.capacity() << endl;

    // invalid iterator
    vector<int>::iterator it = v1.begin();
    cout << *it << endl;

    v1.push_back(99);
    v1.push_back(108);
    cout << *it << endl; // 危险！

    it = v1.begin();
    cout << *it << endl;

    // insert
    v1.insert(v1.begin() + 2, 123);
    print("v1: ", v1);

    // delete
    v1.erase(v1.end() - 2);
    print("v1: ", v1);
    cout << "------------------------------\n";
}
