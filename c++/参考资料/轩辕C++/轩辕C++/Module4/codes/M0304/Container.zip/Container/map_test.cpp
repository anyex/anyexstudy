/*
 * map_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <map>

#include "utils.h"

using namespace std;

int main() {
    typedef map<string, int>::iterator iter;

    map<string, int> m1;
    m1.insert(pair<string, int> ("Knuth", 0));
    m1.insert(make_pair("Joy", 1));

    pair<iter, bool> res = m1.insert(make_pair("Joy", 2));
    cout << boolalpha << res.second << endl;
    cout << res.first->first << endl;

    m1["stallman"] = 2;
    // pair<iterator, bool> res = m1.insert(make_pair("stallman", int()));
    // res.first->second = 2;

    m1["Bill"] = 7;
    m1["Bjarne"] = 0;
    m1["Bill"] = 12;

    print("m1:", m1);

    multimap<string, int> m2;
    m2.insert(pair<string, int> ("Knuth", 0));
    m2.insert(make_pair("Kai", 128));
    m2.insert(make_pair("Bill", 1));
    m2.insert(make_pair("Bill", 3));
    m2.insert(make_pair("Bill", 8));
    print("m2:", m2);

    typedef multimap<string, int>::iterator miter;
    miter it = m2.lower_bound("Bill");
    cout << "m2.lower_bound():" << endl;
    cout << it->first << ' ' << it->second << endl;

    miter itu = m2.upper_bound("Bill");
    cout << "m2.upper_bound():" << endl;
    cout << itu->first << ' ' << itu->second << endl;

    pair<miter, miter> res2 = m2.equal_range("Bill");
    cout << "m2.equal_range():" << endl;
    cout << res2.first->first << ' ' << res2.first->second << endl;
    cout << res2.second->first << ' ' << res2.second->second << endl;
}
