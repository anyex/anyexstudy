/*
 * bitset_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <bitset>
using namespace std;

int main() {
    bitset<16> bs = 1L;
    cout << bs.to_string() << endl;

    bitset<12> bs2(string("01001001"));
    cout << bs2.to_string() << endl;
    cout << bs2[0] << endl;

    bs2.flip();
    cout << bs2.to_string() << endl;

    bs2.set();
    cout << bs2.to_string() << endl;

    bs2.reset();
    cout << bs2.to_string() << endl;

    bs2.set(3);
    cout << bs2.to_string() << endl;

    bs2.set(2, false);
    cout << bs2.to_string() << endl;
    cout << bs2.to_ulong() << endl;
}
