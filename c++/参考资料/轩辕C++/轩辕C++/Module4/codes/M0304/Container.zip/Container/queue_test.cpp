/*
 * queue_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <queue>
#include <list>

#include "utils.h"

using namespace std;

int main() {
    queue<int> q1;
    q1.push(12);
    q1.push(23);
    q1.push(66);

    while (!q1.empty()) {
        cout << q1.front() << ' ';
        q1.pop();
    }
    cout << endl;
}
