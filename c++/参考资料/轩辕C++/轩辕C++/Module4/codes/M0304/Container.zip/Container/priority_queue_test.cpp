/*
 * priority_queue_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <queue>

#include "utils.h"

using namespace std;

int main() {
    priority_queue<int> q;
    q.push(12);
    q.push(23);
    q.push(66);
    q.push(28);
    q.push(78);
    q.push(46);

    while (!q.empty()) {
        cout << q.top() << ' ';
        q.pop();
    }
    cout << endl;
}
