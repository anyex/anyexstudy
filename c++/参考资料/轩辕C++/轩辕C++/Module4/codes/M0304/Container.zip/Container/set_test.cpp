/*
 * set_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <set>

#include "utils.h"

using namespace std;

int main() {
    typedef set<string>::iterator iter;

    set<string> m1;
    m1.insert("Knuth");
    m1.insert("Joy");

    pair<iter, bool> res = m1.insert("Joy");
    cout << boolalpha << res.second << endl;
    cout << *res.first << endl;

    print("m1:", m1);

    multiset<string> m2;
    m2.insert("Knuth");
    m2.insert("Kai");
    m2.insert("Bill");
    m2.insert("Bill");
    m2.insert("Bill");
    print("m2:", m2);

    typedef multiset<string>::iterator miter;
    miter it = m2.lower_bound("Bill");
    cout << "m2.lower_bound():" << endl;
    cout << *it << endl;

    miter itu = m2.upper_bound("Bill");
    cout << "m2.upper_bound():" << endl;
    cout << *itu << endl;

    pair<miter, miter> res2 = m2.equal_range("Bill");
    cout << "m2.equal_range():" << endl;
    cout << *res2.first << endl;
    cout << *res2.second << endl;
}
