/*
 * partition_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a1[] = { 21, 13, 65, 37, 56, 23 };
    partition(a1, a1 + 6, bind2nd(less<int> (), 30));
    // output: 21 13 23 37 56 65  (不保证元素的相对次序)
    copy(a1, a1 + 6, ostream_iterator<int> (cout, " "));
    cout << endl;

    int a2[] = { 21, 13, 65, 37, 56, 23 };
    stable_partition(a2, a2 + 6, bind2nd(less<int> (), 30));
    // output: 21 13 23 37 56 65  (保证元素的相对次序)
    copy(a2, a2 + 6, ostream_iterator<int> (cout, " "));
    cout << endl;
}
