/*
 * set_op.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a1[] = { 21, 13, 65, 37, 56 };
    int a2[] = { 12, 13, 65, 1, 0 };

    sort(a1, a1 + 5);
    sort(a2, a2 + 5);

    list<int> ls;
    set_symmetric_difference(a1, a1 + 5, a2, a2 + 5, back_inserter(ls));
    print("ls: ", ls);

    list<int> ls2;
    set_union(a1, a1 + 5, a2, a2 + 5, back_inserter(ls2));
    print("ls2: ", ls2);

    list<int> ls3;
    set_intersection(a1, a1 + 5, a2, a2 + 5, back_inserter(ls3));
    print("ls3: ", ls3);
}
