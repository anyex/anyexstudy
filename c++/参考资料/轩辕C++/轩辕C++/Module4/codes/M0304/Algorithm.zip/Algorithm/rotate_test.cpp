/*
 * rotate_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 23, 23, 84, 75, 56, 56, 7, 18, 22 };
    list<int> ls(a, a + 10);

    print("ls: ", ls);

    list<int>::iterator mid = find(ls.begin(), ls.end(), 75);
    rotate(ls.begin(), mid, ls.end());

    print("ls: ", ls);

    // output:
    // old: ls: 22 23 23 84 75 56 56 7 18 22
    // new: ls: 75 56 56 7 18 22 22 23 23 84

}
