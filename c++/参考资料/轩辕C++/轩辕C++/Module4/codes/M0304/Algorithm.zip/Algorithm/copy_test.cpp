/*
 * copy_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 52, 23, 84, 75, 56, 56, 7, 18, 22 };
    int b[10] = { };

    // copy
    copy(a + 3, a + 9, b);
    print("b: ", b, 10);
    copy(b, b + 10, ostream_iterator<int> (cout, " "));
    cout << endl;

    // copy
    vector<int> v;
    cout << v.size() << endl;
    //    copy(a, a + 8, v.begin()); // 危险！
    copy(a, a + 8, back_inserter(v));
    print("v: ", v);

    cout << "-----------------------------\n";
}
