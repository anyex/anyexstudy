/*
 * count_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 52, 23, 84, 75, 56, 56, 7, 18, 22 };
    int b[] = { 75, 56, 56, 7 };

    // search
    int* pos = search(a, a + 10, b, b + 4);
    assert(pos == &a[4]);

    // search_n
    pos = search_n(a + 2, a + 8, 2, 56);
    cout << *pos << endl;
    assert(pos == &a[5]);

}
