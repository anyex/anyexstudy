/*
 * find_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 12, 52, 23, 84, 75, 56, 56, 7, 18, 22 };

    // find
    int* pos1 = find(a, a + 6, 75);
    cout << (pos1 == a + 4) << endl;

    // find_if & bind2nd
    typedef vector<int>::iterator iter;
    vector<int> v1(a, a + 10);
    iter it = find_if(v1.begin(), v1.end(), bind2nd(greater<int> (), 70));
    assert(it == v1.begin() + 3);

    // find_if & bind1st
    it = find_if(v1.begin(), v1.end(), bind1st(greater<int> (), 70));
    assert(it == v1.begin());

    // find_first_of
    int a2[] = { 84, 75, 56, 56 };
    iter it2 = find_first_of(v1.begin(), v1.end(), a2, a2 + 4);
    assert(it2 == v1.begin() + 3);

    // adjacent_find
    // v1: {12, 52, 23, 84, 75, 56, 56, 7, 18, 22}
    iter it3 = adjacent_find(v1.begin(), v1.end());
    assert(it3 == v1.begin() + 5);
}
