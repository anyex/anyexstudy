/*
 * fill_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */
#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

struct Generator {
    Generator(int i) :
        n(i) {
    }
    int operator()() {
        return int((double(rand()) / RAND_MAX) * n);
    }
private:
    int n;
};

int main() {
    int a1[16];
    int a2[16];
    vector<int> v;

    fill(a1, a1 + 16, 88);
    print("a1: ", a1, 16);

    generate(a2, a2 + 16, Generator(100));
    print("a2: ", a2, 16);

    fill_n(back_inserter(v), 20, 88);
    print("v: ", v);
}
