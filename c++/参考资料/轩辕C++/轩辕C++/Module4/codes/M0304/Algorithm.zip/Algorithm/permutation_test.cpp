/*
 * permutation_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */
#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    char ss[] = "abcd";
    cout << ss << endl;
    while (next_permutation(ss, ss + 4)) // 4 * 3 * 2 个排列组合
        cout << ss << endl;
}
