/*
 * count_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 52, 23, 84, 75, 56, 56, 7, 18, 22 };
    cout << count(a, a + 10, 29) << endl;

    cout << count_if(a, a + 10, bind2nd(less<int> (), 42)) << endl;

}
