/*
 * unique_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */
#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 23, 23, 84, 75, 56, 56, 7, 18, 22 };
    list<int> ls(a, a + 10);

    print("ls: ", ls);
    //    list<int>::iterator it = unique(ls.begin(), ls.end());
    //    cout << *it << endl;
    //    ls.erase(it, ls.end());
    ls.erase(unique(ls.begin(), ls.end()), ls.end());
    print("ls: ", ls);
}
