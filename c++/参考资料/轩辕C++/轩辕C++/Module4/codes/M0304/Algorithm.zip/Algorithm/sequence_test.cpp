/*
 * sequence_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 12 };

    copy(a, a + 6, ostream_iterator<int> (cout, " "));
    cout << endl;

    int* p = a;
    ++p;
    cout << *p << endl;
    cout << p[1] << endl;
}
