/*
 * nth_element_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 23, 23, 84, 75, 56, 56, 7, 18, 22 };

    print("a: ", a, 10);
    nth_element(a, a + 4, a + 10);
    print("a: ", a, 10);

}
