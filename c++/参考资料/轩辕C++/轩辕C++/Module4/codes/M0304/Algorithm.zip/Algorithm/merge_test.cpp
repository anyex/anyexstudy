/*
 * merge_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a1[] = { 1, 3, 5, 7 };
    int a2[] = { 2, 4, 6, 8 };
    int a3[8];

    merge(a1, a1 + 4, a2, a2 + 4, a3);
    // output: 1 2 3 4 5 6 7 8
    copy(a3, a3 + 8, ostream_iterator<int> (cout, " "));
    cout << endl;

    int a4[] = { 1, 3, 5, 7, 2, 4, 6, 8 };
    inplace_merge(a4, a4 + 4, a4 + 8);
    // output: 1 2 3 4 5 6 7 8
    copy(a4, a4 + 8, ostream_iterator<int> (cout, " "));
    cout << endl;
}
