/*
 * transform_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    int a[] = { 22, 52, 23, 84, 75, 56, 56, 7, 18, 22 };
    int b[] = { 12, 23, 66, 84, 75, 56, 56, 9, 16, 32 };
    int c[10];

    transform(a, a + 10, b, c, plus<int> ());
    print("c: ", c, 10);

    transform(c, c + 10, a, bind1st(minus<int> (), 100));
    print("a: ", a, 10);
}
