/*
 * replace_test.cpp
 *
 *  Created on: 2010-2-13
 *      Author: kwarph
 */

#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
#include <cassert>
#include "utils.h"

using namespace std;

int main() {
    string s("kwarph:100:100:*:kod");
    replace(s.begin(), s.end(), ':', '-');
    cout << s << endl;

    int a[] = { 22, 23, 23, 84, 75, 56, 56, 7, 18, 22 };
    list<int> ls(a, a + 10);


    print("ls: ", ls);
    replace(ls.begin(), ls.end(), 18, 108);
    print("ls: ", ls);

    replace_if(ls.begin(), ls.end(), bind2nd(less<int> (), 70), 1860);
    print("ls: ", ls);

    int b[ls.size()];
    replace_copy(ls.begin(), ls.end(), b, 1860, 186);
    print("ls: ", ls);
    print("b: ", b, ls.size());
}
