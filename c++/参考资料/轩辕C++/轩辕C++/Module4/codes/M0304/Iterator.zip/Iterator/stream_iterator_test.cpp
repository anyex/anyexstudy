/*
 * stream_iterator_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include <iostream>
#include <iterator>
#include <vector>
#include <list>
#include <set>
using namespace std;

int main() {
    //    ostream_iterator<int> oi(cout);
    //    *oi = 7; // 输出 7 (cout << 7)
    //    cout << endl;
    //    ++oi; // 准备下一次输出，不要忘记++
    //    *oi = 12;
    //    cout << endl;
    //
    //    istream_iterator<int> ii(cin);
    //    int i = *ii;
    //    cout << i << endl;
    //    ++ii;
    //    int j = *ii;
    //    cout << j << endl;

    vector<int> v;
    // 注意：istream_iterator<int> ()创建一个空迭代器，通常用作结束标志
    copy(istream_iterator<int> (cin), istream_iterator<int> (),
            back_inserter(v));

    copy(v.begin(), v.end(), ostream_iterator<int> (cout, " "));
    cout << endl;
}
