/*
 * inserter_test.cpp
 *
 *  Created on: 2010-2-14
 *      Author: kwarph
 */

#include <iostream>
#include <iterator>
#include <vector>
#include <list>
#include <set>
using namespace std;

int main() {
    int a[] = { 12, 34, 78, 9, 87, 12 };

    //    vector<int> ls(3);
    //    copy(a, a + 6, ls.begin()); // 一定溢出，危险
    vector<int> ls;
    copy(a, a + 6, back_inserter(ls));
    copy(ls.begin(), ls.end(), ostream_iterator<int> (cout, " "));
    cout << endl;

    // operator[] for rondom access iiterator
    cout << "begin it\n";
    vector<int>::iterator it = ls.begin() + 2;
    for (int i = 0; i < ls.size() - 2; ++i) {
        cout << it[i] << ' ';
    }
    cout << "\nend it\n";

    back_insert_iterator<vector<int> > bi(ls);
    bi = 108;
    bi = 128;
    copy(ls.begin(), ls.end(), ostream_iterator<int> (cout, " "));
    cout << endl;

    set<int> s;
    s.insert(18);
    s.insert(19);
    s.insert(12);

    // 以下操作不允许
    //    back_insert_iterator<set<int> > b12(s);
    //    b12 = 3;
    //    b12 = 6;

    copy(s.begin(), s.end(), ostream_iterator<int> (cout, " "));
    cout << endl;

    list<int> lst(a, a + 6);
    copy(lst.begin(), lst.end(), ostream_iterator<int> (cout, " "));
    cout << endl;

    inserter(lst, ++lst.begin()) = 108;
    inserter(lst, ++lst.begin()) = 128;
    cout << "----------------------------\n";
    copy(lst.begin(), lst.end(), ostream_iterator<int> (cout, " "));
    cout << endl;
    cout << "----------------------------\n";
}
