#include <iostream>
#include <vector>
using namespace std;

class A {
	int k;
public:
	A() {

	}

	A(int j) {

	}
};

int main() {
	A a(5);

	A ar[3];
	vector<A> (3);
}
