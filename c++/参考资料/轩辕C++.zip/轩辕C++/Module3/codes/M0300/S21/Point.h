/*
 * Point.h
 * 
 *  Created on: 2009-12-25 上午09:39:13
 *      Author: kwarph
 */

#ifndef POINT_H_
#define POINT_H_

/*
 *
 */
struct Point {
	double x, y;
};

#endif /* POINT_H_ */
