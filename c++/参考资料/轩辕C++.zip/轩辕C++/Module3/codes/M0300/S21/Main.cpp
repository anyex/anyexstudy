/*
 * Main.cpp
 * 
 *  Created on: 2009-12-25 上午09:47:38
 *      Author: kwarph
 */

#include <iostream>

#include "Circle.h"
#include "Rectangle.h"

int main() {
	Circle c;
	c.draw();

	Rectangle r;
	r.draw();
}
