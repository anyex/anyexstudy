/*
 * Triangle.cpp
 * 
 *  Created on: 2009-12-25 上午10:28:54
 *      Author: kwarph
 */

#include <iostream>

#include "Triangle.h"

Triangle::Triangle() {
}

Triangle::~Triangle() {
}

void Triangle::draw() const {
	std::cout << "Triangle::draw()\n";
}
