#include <iostream>
using namespace std;

#define BUF_SIZE 512
#define MAIN main

int MAIN() {
	int array[BUF_SIZE];
}
