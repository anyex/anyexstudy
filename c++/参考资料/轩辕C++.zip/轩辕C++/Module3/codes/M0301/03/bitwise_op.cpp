#include <iostream>
using namespace std;

int main() {
	cout << (1 & 2) << endl;
	cout << (3 ^ 5) << endl;
	cout << (3 | 8) << endl;
}
