#include <iostream>
using namespace std;

int main() {
	cout << "please enter a number: ";
	int i;
	cin >> i;
	cout << (i > 8 ? "i > 8" : "i <= 8") << endl;
}
