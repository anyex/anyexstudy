
static int i = 8;
