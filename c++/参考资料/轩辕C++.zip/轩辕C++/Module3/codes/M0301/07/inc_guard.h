#ifndef INC_GUARD_H_
#define INC_GUARD_H_

class A {
	int n;

public:
	void f();
};

#endif
