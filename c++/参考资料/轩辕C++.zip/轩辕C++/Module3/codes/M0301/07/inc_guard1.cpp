#include "inc_guard.h"

void A::f() {

}
