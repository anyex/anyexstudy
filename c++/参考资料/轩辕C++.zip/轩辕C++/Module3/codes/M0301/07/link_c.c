#include "link_c.h"

void fc() {

}
