#include "link_c.h"

extern "C" void fc();

int main() {
	fc();
}
