#include <iostream>
using namespace std;

int main() {
	extern int i;
	cout << i << endl;
}
