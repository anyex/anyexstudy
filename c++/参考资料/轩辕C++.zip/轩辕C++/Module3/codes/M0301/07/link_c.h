#ifndef LINK_C_H_
#define LINK_C_H_

#ifdef __cplusplus
extern "C" {
#endif

void fc();

#ifdef __cplusplus
}
#endif

#endif
