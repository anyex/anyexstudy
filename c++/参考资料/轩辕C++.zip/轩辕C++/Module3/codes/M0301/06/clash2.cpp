#include "clash.h"

void f2() {

}
