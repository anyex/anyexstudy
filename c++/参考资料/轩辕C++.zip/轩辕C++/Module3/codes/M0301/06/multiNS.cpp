#include "multiNS1.h"
#include "multiNS2.h"

int main() {
	ns1::func1();
	ns1::func4();
}
