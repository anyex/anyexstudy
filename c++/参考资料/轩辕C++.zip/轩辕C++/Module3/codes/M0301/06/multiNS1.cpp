#include "multiNS1.h"

void ns1::func1() {
}

void ns1::func2() {
}
