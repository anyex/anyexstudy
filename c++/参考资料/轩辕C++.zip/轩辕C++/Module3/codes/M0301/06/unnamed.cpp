#include "unnamed.h"

int main() {
	f1();
	f2();
}
