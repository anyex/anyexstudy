#ifndef MULTI_NS2_H_
#define MULTI_NS2_H_

namespace ns1 {
void func3();
void func4();
}

#endif
