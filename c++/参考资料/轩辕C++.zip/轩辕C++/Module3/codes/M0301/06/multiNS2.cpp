#include "multiNS2.h"

void ns1::func3() {
}

void ns1::func4() {
}
