#ifndef MULTI_NS1_H_
#define MULTI_NS1_H_

namespace ns1 {
void func1();
void func2();
}

#endif
