#ifndef CLASH_H_
#define CLASH_H_

int n;

void f1();
void f2();

#endif
