#include "unnamed.h"

namespace {
int n;
}

void f1() {
	n+=3;
}
