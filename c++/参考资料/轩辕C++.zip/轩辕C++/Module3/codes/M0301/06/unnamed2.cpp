#include "unnamed.h"

namespace {
int n;
}

void f2() {
	n+=2;
}
