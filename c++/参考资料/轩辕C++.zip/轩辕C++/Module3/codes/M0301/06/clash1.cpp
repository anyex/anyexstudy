#include "clash.h"

void f1() {

}
