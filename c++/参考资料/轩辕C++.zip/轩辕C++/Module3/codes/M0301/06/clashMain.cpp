#include "clash.h"

int main() {
	f1();
	f2();
}
