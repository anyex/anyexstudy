#ifndef UNNAMED_H_
#define UNNAMED_H_

void f1();
void f2();

#endif
