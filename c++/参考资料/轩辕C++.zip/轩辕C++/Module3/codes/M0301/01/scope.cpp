#include <iostream>
using namespace std;

double n = 0.;

int main() {
	int n = 1;
	int m , k;
	{
		int n = 9;			
		cout << "n == " << n << endl;
	}
	cout << "n == " << n << endl;
}
