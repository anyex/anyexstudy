#ifndef A_D_
#define A_D_

struct A {
	A() {
	}
		
};

enum Color { RED, GREEN, BLUE };

#endif
