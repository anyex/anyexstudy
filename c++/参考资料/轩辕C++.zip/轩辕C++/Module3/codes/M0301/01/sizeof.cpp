#include <iostream>
using namespace std;

int main() {
	cout << "sizeof int: " << sizeof(int) << endl;
	cout << "sizeof long: " << sizeof(long) << endl;
	cout << "sizeof float: " << sizeof(float) << endl;
	cout << "sizeof double: " << sizeof(double) << endl;
	cout << "sizeof long double: " << sizeof(long double) << endl;
}
