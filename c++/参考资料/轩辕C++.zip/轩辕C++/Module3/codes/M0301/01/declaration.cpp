#include <iostream>

#include "declaration.h"

using namespace std;

class A;

int main() {
	A a;
}


