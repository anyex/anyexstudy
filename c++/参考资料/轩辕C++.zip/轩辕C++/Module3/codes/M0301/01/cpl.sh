#!/bin/bash
g++ -o $1 ${1}.cpp -g -Wall
