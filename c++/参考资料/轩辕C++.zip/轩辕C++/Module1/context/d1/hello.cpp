#include <iostream>

int main() {
	std::cout << "hello, world!\n";
	return 0;
}
